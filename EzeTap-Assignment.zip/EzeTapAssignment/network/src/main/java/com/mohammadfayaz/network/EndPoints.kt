package com.mohammadfayaz.network

object EndPoints {
  const val BASE_URL = "https://demo.ezetap.com/"
  const val JSON_UI = "mobileapps/android_assignment.json"
}
